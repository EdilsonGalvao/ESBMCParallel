/*++
Copyright (c) 2011 Microsoft Corporation

Module Name:

    eval_cmd.h

Abstract:

    eval_cmd

Author:

    Leonardo (leonardo) 2011-04-30

Notes:

--*/
#ifndef _EVAL_CMD_H_
#define _EVAL_CMD_H_

class cmd_context;

void install_eval_cmd(cmd_context & ctx);

#endif
